package testCases;

import java.io.IOException;

import org.testng.annotations.Test;

import reportAndStamps.ExcelWriteData;
import setupClasses.BrowserSetup;
import setupClasses.WebpageSetup;
import webPageClasses.HomeLoan;

public class HomeLoanTest extends BrowserSetup{
	HomeLoan homeLoan;
	
	@Test
	public void calculateLoan() throws InterruptedException, IOException {
		invokeBrowser("Chrome");
		WebpageSetup pageBase = new WebpageSetup(driver);
		homeLoan = new HomeLoan(pageBase.openWebsite());
		homeLoan.calculateHomeLoan();
		ExcelWriteData.writeData(homeLoan.printResult());
	}
}
