package testCases;

import java.io.IOException;
import org.testng.annotations.Test;

import reportAndStamps.ExcelWriteData;
import setupClasses.BrowserSetup;
import setupClasses.WebpageSetup;
import webPageClasses.CarLoan;

public class CarLoanTest extends BrowserSetup{
	CarLoan carLoan;
	
	@Test
	public void calculateLoan() throws IOException, InterruptedException {
		invokeBrowser("Mozilla");
		WebpageSetup pageBase = new WebpageSetup(driver);
		carLoan = new CarLoan(pageBase.openWebsite());
		carLoan.calculateCarLoan();
		carLoan.GetResult();
		ExcelWriteData.writeData(carLoan.GetResult());
	}
}
