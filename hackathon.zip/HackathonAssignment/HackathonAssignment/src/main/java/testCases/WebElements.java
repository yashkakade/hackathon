package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import setupClasses.BrowserSetup;
import setupClasses.LoanPageSetup;
import webPageClasses.CalculateEMI;
import webPageClasses.LoanAmount;
import webPageClasses.LoanTenure;

public class WebElements extends BrowserSetup{
	CalculateEMI emiCalPage;
	LoanAmount loanAmtPage;
	LoanTenure loanTenurePage;
	LoanPageSetup menuClass = new LoanPageSetup(driver);
	
	@Test
	public void EMITest() throws InterruptedException {
		invokeBrowser("Chrome");
		LoanPageSetup menuClass = new LoanPageSetup(driver);
		emiCalPage = new CalculateEMI(menuClass.gotoLoanCalculator());
		emiCalPage.LoanAmtTextBox();
		emiCalPage.InterestRateTextBox();
		emiCalPage.LoanTenureTextBox();
		emiCalPage.FeesChargesTextBox();
		emiCalPage.LoanAmtSlider();
		emiCalPage.InterestRateSlider();
		emiCalPage.LoanTenureSlider();
		emiCalPage.FeesChargesSlider();
	}
	
	@Test
	public void LoanAmount() throws InterruptedException {
		invokeBrowser("Chrome");
		LoanPageSetup menuClass = new LoanPageSetup(driver);
		loanAmtPage = new LoanAmount(menuClass.gotoLoanCalculator());
		loanAmtPage.switchTab();
		loanAmtPage.EMITextBox();
		loanAmtPage.InterestRateTextBox();
		loanAmtPage.LoanTenureTextBox();
		loanAmtPage.FeesChargesTextBox();
		loanAmtPage.EMISlider();
		loanAmtPage.InterestRateSlider();
		loanAmtPage.LoanTenureSlider();
		loanAmtPage.FeesChargesSlider();
	}
	
	@Test
	public void LoanTenure() throws InterruptedException {
		invokeBrowser("Chrome");
		LoanPageSetup menuClass = new LoanPageSetup(driver);
		loanTenurePage = new LoanTenure(menuClass.gotoLoanCalculator());
		loanTenurePage.switchTab();
		loanTenurePage.checkLoanAmtTextBox();
		loanTenurePage.checkEMITextBox();
		loanTenurePage.checkInterestRateTextBox();
		loanTenurePage.checkFeesChargesTextBox();
		loanTenurePage.checkLoanAmtSlider();
		loanTenurePage.checkEMISlider();
		loanTenurePage.checkInterestRateSlider();
		loanTenurePage.checkFeesChargesSlider();
	}
	
	@AfterClass
	public void quitBrowser() {
		driver.quit();
	}

}
