package reportAndStamps;

import java.util.Date;

public class DateStamp {
		
		public static String getTimeStamp(){
			Date date = new Date();
			return date.toString().replaceAll(":", "_").replaceAll(" ", "_");
		}
}