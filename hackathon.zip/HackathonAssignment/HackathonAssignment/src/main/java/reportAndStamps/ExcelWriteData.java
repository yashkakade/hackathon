package reportAndStamps;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriteData {
	
	/******** Write Data for Single Row *********/
	public static void writeData(List<String> data) throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet();
		
		int rowCount = 0;
		
		for (String value : data) {
			Row row = sheet.createRow(++rowCount);
			Cell cell = row.createCell(1);
			cell.setCellValue(value);
		}
		
		try (FileOutputStream outputStream = new FileOutputStream("DataOutput.xlsx")) {
			workbook.write(outputStream);
			workbook.close();
		}
	}
	
	/********* Write Data for Tabular Data ***********/
	public static void writeData(ArrayList<ArrayList<String>> data) throws IOException{
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet();
		
		int rowCount = 0;
		for (ArrayList<String> rowData : data) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			for (String value: rowData) {
				Cell cell = row.createCell(columnCount++);
				cell.setCellValue(value);
			}
		}
		
		try (FileOutputStream outputStream = new FileOutputStream("CarOutput.xlsx")) {
			workbook.write(outputStream);
			workbook.close();
		}
	}
}
