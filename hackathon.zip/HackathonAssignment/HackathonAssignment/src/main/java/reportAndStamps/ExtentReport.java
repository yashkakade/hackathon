package reportAndStamps;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;


public class ExtentReport {
	
	//public static ExtentHtmlReporter htmlReporter;
		public static ExtentReports rep;
		
		public static ExtentReports getReportInstance(){
			
			if(rep == null){
				String reportName = DateStamp.getTimeStamp() + ".html";
				ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/" + reportName);
				rep =  new ExtentReports();
				rep.attachReporter(htmlReporter);
				
				rep.setSystemInfo("OS", "Windows 10");
				rep.setSystemInfo("Environment", "UAT");
				rep.setSystemInfo("Build Number", "10.8.1");
				rep.setSystemInfo("Browser", "Chrome");
				
				htmlReporter.config().setDocumentTitle("UAT UI Automation Results");
				htmlReporter.config().setReportName("All Headlines UI Test Report");
				htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
				htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
			}
			
			return rep;
		}

}