package setupClasses;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class LoanPageSetup extends WebpageSetup{

	public LoanPageSetup(WebDriver driver) {
		super(driver);
	}
	
	/********* Open Loan Calculator Page **********/
	public WebDriver gotoLoanCalculator() {
		openWebsite();
		driver.findElement(By.xpath("//a[@title='Calculators']")).click();
		List<WebElement> options = driver.findElements(By.xpath("//ul[contains(@class,'dropdown')]//a"));
		for (WebElement option : options) {
			if (option.getText().equalsIgnoreCase("Loan Calculator")) {
				option.click();
				break;
			}
		}
		return driver;
	}
	
	/********* Check for TextBox **********/
	public WebElement checkText(String key, String xpath) {
		WebElement element = clearValue(xpath);
		element.sendKeys(key);
		element.sendKeys(Keys.TAB);
		String value = element.getAttribute("value").replaceAll(",", "");
		Assert.assertEquals(value, key);
		return element;
	}
	
	/********* Check for Slider **********/
	public String checkSlider(String xpath1, String xpath2) throws InterruptedException {
		WebElement slider = driver.findElement(By.xpath(xpath1));
		
		WebElement element = clearValue(xpath2);
		
		Thread.sleep(2000);
		element.sendKeys(Keys.TAB);
		Thread.sleep(2000);
		Actions move = new Actions(driver);
		move.dragAndDropBy(slider, 2, 0).perform();
		Thread.sleep(2000);
		String value = element.getAttribute("value");
		return value;
	}
    

}
	






    
