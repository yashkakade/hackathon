package setupClasses;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebpageSetup extends BrowserSetup{
	
	public WebpageSetup(WebDriver driver) {
		this.driver = driver;
	}
	
	/********** Go to emicalculator.net **********/
	public WebDriver openWebsite() {
		driver.get("https://emicalculator.net/");
		return driver;
	}
	
	/********** Filling data **********/
	public void fillData(String amount, String interest, String tenure) throws InterruptedException{
		WebElement loanAmount, interestRate, loanTenure;
		Thread.sleep(5000);
		//findings elements
		loanAmount = driver.findElement(By.id("loanamount"));
		interestRate = driver.findElement(By.id("loaninterest"));
		loanTenure = driver.findElement(By.id("loanterm"));
		
		/********* Putting values *********/
		loanAmount.clear();
		loanAmount.sendKeys(amount);
		Thread.sleep(1000);
		interestRate.sendKeys(Keys.chord(Keys.CONTROL,"a"));
		interestRate.sendKeys(Keys.DELETE);
		interestRate.sendKeys(interest);
		Thread.sleep(1000);
		loanTenure.sendKeys(Keys.chord(Keys.CONTROL,"a"));
		loanTenure.sendKeys(Keys.DELETE);
		loanTenure.sendKeys(tenure);
		loanTenure.sendKeys(Keys.TAB);
	}
	
	/********** Toggling year **********/
	public void clickYear() throws InterruptedException{
		Thread.sleep(2000);
		List<WebElement> years = driver.findElements(By.xpath("//td[contains(@id,'year')]")); //finds all the year toggles
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		for (WebElement year : years)
			while (!year.getAttribute("class").contains("open"))
				jse.executeScript("arguments[0].click()", year);
	}
	
	/********** Selecting drop down values ***********/
	public void selectDropDownValue(WebElement element, String value) {
		try {
			Select select = new Select(element);
			select.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*********** Clearing textbox **********/
	public WebElement clearValue(String xpath) {
		WebElement element = driver.findElement(By.xpath(xpath));
		element.sendKeys(Keys.chord(Keys.CONTROL,"a"));
		element.sendKeys(Keys.DELETE);
		return element;
	}
}
