package webPageClasses;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import setupClasses.WebpageSetup;

public class CarLoan extends WebpageSetup {

	public CarLoan(WebDriver driver) {
		super(driver);
	}
	
	@FindBy (xpath = "//a[contains(text(),'Car Loan')]")
	WebElement carLoanButton;
	
	public void calculateCarLoan() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(text(),'Car Loan')]")).click();
//		carLoanButton.click();
		fillData("1500000", "9.5", "1");
	}
	
	public List<String> GetResult() throws InterruptedException {
		//getYear();
		clickYear();
		String principal = driver.findElement(By.xpath("//tr[contains(@id,'monthyear')][1]//tr[1]/td[2]")).getText();
		String interest = driver.findElement(By.xpath("//tr[contains(@id,'monthyear')][1]//tr[1]/td[3]")).getText();
		System.out.println(principal);
		List<String> data = new ArrayList<String>();
		data.add(principal);
		data.add(interest);
		return data;
	}

}
