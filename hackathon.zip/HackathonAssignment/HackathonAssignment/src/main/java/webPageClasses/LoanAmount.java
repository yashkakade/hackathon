package webPageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import setupClasses.LoanPageSetup;

public class LoanAmount extends LoanPageSetup{

	public LoanAmount(WebDriver driver) {
		super(driver);
	}
	
	public void switchTab() {
		driver.findElement(By.xpath("//a[contains(text(), 'Loan Amount')]")).click();
	}
	
	public void EMITextBox() {
		checkText("10000", "//input[@id='loanemi']");
	}
	
	public void InterestRateTextBox() {
		checkText("2.5", "//input[@id='loaninterest']");
	}
	
	public void LoanTenureTextBox() {
		WebElement tenure = checkText("6", "//input[@id='loanterm']");
		WebDriverWait wait = new WebDriverWait(driver,30);
		WebElement month = driver.findElement(By.xpath("//*[@id='ltermwrapper']/div[1]/div/div/div/div/div/label[2]"));
		wait.until(ExpectedConditions.elementToBeClickable(month));
		month.click();
		Assert.assertEquals(tenure.getAttribute("value"), "72");
	}
	
	public void FeesChargesTextBox() {
		checkText("5000", "//input[@id='loanfees']");
	}


	public void EMISlider()throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loanemislider']","//input[@id='loanemi']");
		System.out.println("(Loan Amount Calculator)The Slider for loanemi is working and the value is being reflecting in the textbox: "+x);
	}
	
	public void InterestRateSlider() throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loaninterestslider']","//input[@id='loaninterest']");
		System.out.println("(Loan Amount Calculator)The Slider for loaninterest is working and the value is being reflecting in the textbox: "+x);

	}
	
	public void LoanTenureSlider() throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loantermslider']","//input[@id='loanterm']");
		System.out.println("(Loan Amount Calculator)The Slider for loanterm is working and the value is being reflecting in the textbox: "+x);

	}
	
	public void FeesChargesSlider() throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loanfeesslider']","//input[@id='loanfees']");
		System.out.println("(Loan Amount Calculator)The Slider for loanfees is working and the value is being reflecting in the textbox: "+x);
	}



















}
