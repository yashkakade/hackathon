package webPageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import setupClasses.LoanPageSetup;

public class LoanTenure extends LoanPageSetup{

	public LoanTenure(WebDriver driver) {
		super(driver);
	}
	
	public void switchTab() {
		driver.findElement(By.xpath("//a[contains(text(), 'Loan Tenure')]")).click();
	}
	
	public void checkLoanAmtTextBox() {
		checkText("5000", "//input[@id='loanamount']");
	}
	
	public void checkEMITextBox() {
		checkText("10000", "//input[@id='loanemi']");
	}
	
	public void checkInterestRateTextBox() {
		checkText("2.5", "//input[@id='loaninterest']");
	}
	
	public void checkFeesChargesTextBox() {
		checkText("5000", "//input[@id='loanfees']");
	}




	


	public void checkLoanAmtSlider() throws InterruptedException{
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loanamountslider']","//input[@id='loanamount']");
		System.out.println("(Loan Tenure Calculator)The Slider for loanamount is working and the value is being reflecting in the textbox: "+x);
	}


	public void checkEMISlider()throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loanemislider']","//input[@id='loanemi']");
		System.out.println("(Loan Tenure Calculator)The Slider for loanemi is working and the value is being reflecting in the textbox: "+x);
	}



	
	public void checkInterestRateSlider() throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loaninterestslider']","//input[@id='loaninterest']");
		System.out.println("(Loan Tenure Calculator)The Slider for loaninterest is working and the value is being reflecting in the textbox: "+x);

	}
	
	public void checkFeesChargesSlider() throws InterruptedException {
		Thread.sleep(5000);
		String x=checkSlider("//div[@id='loanfeesslider']","//input[@id='loanfees']");
		System.out.println("(Loan Tenure Calculator)The Slider for loanfees is working and the value is being reflecting in the textbox: "+x);
	}





}
