package webPageClasses;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import setupClasses.WebpageSetup;

public class HomeLoan extends WebpageSetup{

	public HomeLoan(WebDriver driver) {
		super(driver);
	}
	
	public void calculateHomeLoan() throws InterruptedException {
		fillData("1500000", "9.5", "1");
	}
	
	public ArrayList<ArrayList<String>> printResult() throws InterruptedException{
		clickYear();
		Thread.sleep(5000);
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		List<WebElement> rows = driver.findElements(By.xpath("//div[@id='emipaymenttable']/table//tr[not(descendant::table)]"));
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath("./*"));
			ArrayList<String> cell_data = new ArrayList<String>();
			for (WebElement cell : cells) {
				if ((cell.getTagName().equalsIgnoreCase("td") || cell.getTagName().equalsIgnoreCase("th") )&& cell.getText().length() != 0) {
					cell_data.add(cell.getText());
				}
			}
			data.add(cell_data);
		}
		return data;
	}

}
